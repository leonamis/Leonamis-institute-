require("dotenv").config();
console.log("Server started");