const express = require("express");
const fetch = require("node-fetch");
const router = express.Router();

// AI Lecturer endpoint using Claude API
router.post("/ask", async (req, res) => {
  const { question } = req.body;

  try {
    const response = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: {
        "x-api-key": process.env.CLAUDE_API_KEY,
        "anthropic-version": "2023-06-01",
        "content-type": "application/json"
      },
      body: JSON.stringify({
        model: "claude-3-opus-20240229",
        max_tokens: 300,
        messages: [{ role: "user", content: question }]
      })
    });

    const data = await response.json();
    const aiReply = data?.content?.[0]?.text || "Claude is thinking...";

    res.json({ response: aiReply });
  } catch (err) {
    console.error(err);
    res.status(500).send("Error reaching Claude");
  }
});

module.exports = router;